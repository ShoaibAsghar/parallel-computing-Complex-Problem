#include <stdio.h>
#include<limits.h>
#include <string.h>
#include <stdlib.h>
#define INFINITY 9999

long int matrix[20][20];
char concate_Array1[100] = "";
int initial_Array[20][20],Array_Rows[20],i,j,elements;
char brackets_Arr[1] = "A";





int MatrixOrder(int Array_Rows[], int m, int n)
{
    	if(m == n)
		   {
        	 return 0;
		   }

    	int k,counter;
    	int minimum = INT_MAX;
 
    	for (k = m; k <n; k++)
    	{
        	counter = MatrixOrder(Array_Rows, m, k) + MatrixOrder(Array_Rows, k+1, n) + Array_Rows[m-1]*Array_Rows[k]*Array_Rows[n];
 
        	if(counter < minimum)
			{
			    minimum = counter;
			}

			// else {
			// 	//nothing
			// }
    	}
 
    	return minimum;
}

void Func_Scalar_Matrix_MUL (void)
{
	long int a;
	int b;
	
	for(i=elements; i>0; i--)
 	{
   		for(j=i; j<=elements; j++)
    		{
     			if(i == j)
				  {
       			    matrix[i][j] = 0;
				  }

     			else if(i != j)
       		        {
                     //  b=i;

        			   for(b=i; b < j; b++ )
        			      {
         				     a = matrix[i][b] + matrix[b+1][j] + Array_Rows[i-1] * Array_Rows[b] * Array_Rows[j];

         				     if( a < matrix[i][j])
          				       {
            					  matrix[i][j] = a;
            					  initial_Array[i][j] = b;
          				       }
                              
							//   else{
							// 	//nothing
							//   }

							   
         			      }


        	    	}
      		}
 	}
}


void printOrder(int a,int b)
    {

	  if(a!=b)
           {	
      		strcat(concate_Array1, "(");
      		
      		printOrder(i, initial_Array[i][b]);
      		printOrder(initial_Array[i][b] + 1, b);
      		
      		strcat(concate_Array1, ")*");
   	       }

	  else if (a == b)
	         {
		       strcat(concate_Array1, brackets_Arr);
		
		       brackets_Arr[0]++;
	         }
  	
     	printf( &concate_Array1[strlen(concate_Array1)-1]);
}


void Func_File_Read () {
    
	int num_Rows[5];
    int num_Cols[5];

    FILE * ptr_file;
    char * ptr_Line = NULL;
    size_t str_length = 0;
    ssize_t str_read_length;

    ptr_file = fopen("matrices.txt", "r");

    if (ptr_file == NULL)
	{
      printf("Problem with the file\n");
      exit(EXIT_FAILURE);

    }
       
    int i, j, length_counter;
    char Remove_Null_strArray[10][10];

    int Array_counter = 0;

    while ((str_read_length = getline(&ptr_Line, &str_length, ptr_file)) != -1) 
	{

      
        j=0; length_counter=0;

        for(i=0; i <= (strlen(ptr_Line)) ; i++ ) 
		   {
            if(ptr_Line[i]==' '||ptr_Line[i]=='\0') 
			  {
                 Remove_Null_strArray[length_counter][j] = '\0';
                 length_counter++;  

                  j = 0;    

              }
			  
			   else 
			       {
                     Remove_Null_strArray[length_counter][j] = ptr_Line[i];
                     j++;
                   }
         }
        
        num_Rows[Array_counter] = atoi(Remove_Null_strArray[0]);

        num_Cols[Array_counter] = atoi(Remove_Null_strArray[2]);

        Array_counter++;
    }
    
	 printf("Dimenstion of Matrices: \n");
      for(int i=0; i<5; i++){
           printf("%d * %d \n", num_Rows[i], num_Cols[i]);
	  }
    //return Array_counter;
}


int main()
{
	int k;
	int num;
	Func_File_Read();
	
	printf("Enter Total Number of Matrix: ");
	scanf(" %d ", &elements );
	//cin.ignore(100,'\n')
	for(i=1; i<=elements; i++)
	   {
		  for(j=i+1; j <= elements; j++)
	     	{
 			  matrix[i][i] = 0;
             //
			 //
 			  matrix[i][j] = INFINITY;
			  
 		 	  initial_Array[i][j] = 0;

		    }
	   }

		printf("\nEnter Dimensions of matrices: \n");
		
		for(k=0; k <= elements; k++)
		   {

 			 printf("P%d, ", k);

 			 scanf("%d", &Array_Rows[k] );

		   }
		
		Func_Scalar_Matrix_MUL();

		printf("\n****Cost of Matrix****\n");

		for(i=1; i<=elements; i++ )
		    {
 			  for( j=i; j<=elements; j++ )
			     {
  				   printf("matrix[%d][%d]: %ld\n", i, j, matrix[i][j]);
				 }
			}

		i=1;
		
		j=elements;
		
		printf("\n Multiplication sequence is: ");
		
		printOrder(i, j);
		printf("\n");
		
		printf(concate_Array1);

		printf("\nOptimal multiplications : %d ", MatrixOrder(Array_Rows, 1, elements));

}
