#include<stdlib.h>
#include<stdio.h>
#include "mpi.h"
#include<time.h>
#include<sys/time.h>
#include<string.h>

void Multiplication_By_Blocking(int Rows_1,int Columns_1,int Rows_2,int Columns_2, int Number_of_Slave_Task,double Martix_1[][Columns_1],double Matrix_2[][Columns_2])
  
  {
    double Matrix_3[Rows_1][Columns_2];

    int No_of_rows = Rows_1/Number_of_Slave_Task;
    
    int offset = 0;
    int Ending_Point,Starting_Point;
    MPI_Status Current_Status;
 
    for (Ending_Point=1; Ending_Point <= Number_of_Slave_Task; Ending_Point++)
        {
      
         MPI_Send(&offset, 1, MPI_INT, Ending_Point, 1, MPI_COMM_WORLD);
     
         MPI_Send(&No_of_rows, 1, MPI_INT, Ending_Point, 1, MPI_COMM_WORLD);
     
         MPI_Send(&Columns_1, 1, MPI_INT, Ending_Point, 1, MPI_COMM_WORLD);
      
         MPI_Send(&Columns_2, 1, MPI_INT, Ending_Point, 1, MPI_COMM_WORLD);
      
         MPI_Send(&Rows_2, 1, MPI_INT, Ending_Point, 1, MPI_COMM_WORLD);
      
         MPI_Send(&Martix_1[offset][0], No_of_rows*Columns_1, MPI_DOUBLE,Ending_Point,1, MPI_COMM_WORLD);
      
         MPI_Send(Matrix_2, Rows_2*Columns_2, MPI_DOUBLE, Ending_Point, 1, MPI_COMM_WORLD);
      
         offset = offset + No_of_rows;
    }
    
}


MPI_Status Current_Status;

int main(int argc, char **argv)
{
    
    int File_Rows[5];
    
    int File_columns[5];
    
    FILE * File_Pointer;
    char * Characters_in_Line = NULL;
    size_t File_length = 0;
    ssize_t File_Reader;
    
    File_Pointer = fopen("matrices.txt", "r");
    
    if (File_Pointer == NULL)
    {
      printf("Problem with the file\n");
      exit(EXIT_FAILURE);
    }
       
    int Counter_1, Counter_2, Next_Word;
    
    char File_String[10][10];
    int Loop_Iterator = 0;
    
    while ((File_Reader = getline(&Characters_in_Line, &File_length, File_Pointer)) != -1) 
    {

      Counter_1=0;Counter_2=0; Next_Word=0;
      
      while(Counter_1<=(strlen(Characters_in_Line)))
      {
        
        if(Characters_in_Line[Counter_1]==' '||Characters_in_Line[Counter_1]=='\0')
        {
            File_String[Next_Word][Counter_2]='\0';
            Next_Word++;  
            Counter_2=0;    
        }
        
        else
        {
            File_String[Next_Word][Counter_2]=Characters_in_Line[Counter_1];
            Counter_2++;
        }
        
        Counter_1++;
    } 
        File_Rows[Loop_Iterator] = atoi(File_String[0]);
        File_columns[Loop_Iterator] = atoi(File_String[2]);
        Loop_Iterator++;
    }


    
  int processCount, Current_Process_ID, Number_of_Slave_Task, Starting_Point, Ending_Point, No_of_rows, offset;

  struct timeval Start_Time, Stop_Time;

    
    MPI_Init(&argc, &argv);
    
    MPI_Comm_rank(MPI_COMM_WORLD, &Current_Process_ID);
   
    MPI_Comm_size(MPI_COMM_WORLD, &processCount);

    
    Number_of_Slave_Task = processCount - 1;


 if (Current_Process_ID == 0) 
   {

     printf("Dimenstion of Matrices: \n");
   
   for(int Counter_1=0; Counter_1<5; Counter_1++)
      {
        printf("%d * %d \n", File_Rows[Counter_1], File_columns[Counter_1]);
      
      }
   

   for(int Counter_1=0;Counter_1<5-1;++Counter_1)
      {

        int Rows_1 = File_Rows[Counter_1];
        int Columns_1 = File_columns[Counter_1];
        int Rows_2 = File_Rows[Counter_1+1];
        int Columns_2 = File_columns[Counter_1+1];
        double Matrix_1[Rows_1][Columns_1],Matrix_2[Rows_2][Columns_2],Matrix_3[Rows_1][Columns_2];


        srand ( time(NULL) );
        int Counter_3 = 0;
        while ( Counter_3<Rows_1) 
             {
             
              int Counter_2 = 0;
              while ( Counter_2<Columns_1) 
                    {
                      Matrix_1[Counter_3][Counter_2]= Counter_3;
                      Counter_2++;
                    }
                    
             Counter_3++;
           }

        int Counter_4 = 0;
        
        while ( Counter_4<Rows_2) 
              {
                int Counter_2 = 0;
                
                while ( Counter_2<Columns_2 ) 
                      {
                        Matrix_2[Counter_4][Counter_2]= Counter_4;
                        Counter_2++;
                      }
                      
                  Counter_4++;
              }
	
        printf("\n--------------------------\n");

       
        printf("\nFirst Matrixn----->\n");
        int Counter_5 = 0;
        
        while ( Counter_5<Rows_1) 
              {
                int Counter_2 = 0; 
                while (Counter_2<Columns_1) 
                      {
                        printf("%.0f\t", Matrix_1[Counter_5][Counter_2]);
                        Counter_2++;
                      }
                      
               Counter_5++;
               
	        printf("\n");
             }
             

       
        printf("\nSecond Matrix\n\n");
        int Counter_6 = 0;
        
        while ( Counter_6<Rows_2 ) 
              {
                int Counter_2 = 0;
            
                while ( Counter_2<Columns_2 ) 
                      {
                        printf("%.0f\t",  Matrix_2[Counter_6][Counter_2]);
                        Counter_2++;
                      }
                      
                 Counter_6++;
	         printf("\n");
            }

        
        No_of_rows = Rows_1/Number_of_Slave_Task;
        
        offset = 0;


        Multiplication_By_Blocking(Rows_1,Columns_1,Rows_2,Columns_2,Number_of_Slave_Task,Matrix_1,Matrix_2);
     
        int Counter_7 = 1;
        while ( Counter_7 <= Number_of_Slave_Task)
        {
            Starting_Point = Counter_7;
          
            MPI_Recv(&offset, 1, MPI_INT, Starting_Point, 2, MPI_COMM_WORLD, &Current_Status);
          
            MPI_Recv(&No_of_rows, 1, MPI_INT, Starting_Point, 2, MPI_COMM_WORLD, &Current_Status);
           
            MPI_Recv(&Matrix_3[offset][0], No_of_rows*Columns_2, MPI_DOUBLE, Starting_Point, 2, MPI_COMM_WORLD, &Current_Status);
            Counter_7++;

        }
   
            printf("\nResult Matrix \n\n");
            
        int Counter_8 = 0;
        
        while ( Counter_8<Rows_1 ) 
             {
              
              int Counter_2 = 0;
              
              while ( Counter_2<Columns_2)
                   {
                    printf("%.0f\t", Matrix_3[Counter_8][Counter_2]);
                    Counter_2++;
                   }
                   
            printf ("\n");
             Counter_8++;
        }
        
        printf ("\n");
       
    }
	
  }


  if (Current_Process_ID > 0) 
     {

      int Counter_0=0;
      while(Counter_0<5-1)
           {
             
             int Columns_1,No_of_rows2,No_of_columns2;

             Starting_Point = 0;

    

            MPI_Recv(&offset, 1, MPI_INT, Starting_Point, 1, MPI_COMM_WORLD, &Current_Status);
     
            MPI_Recv(&No_of_rows, 1, MPI_INT, Starting_Point, 1, MPI_COMM_WORLD, &Current_Status);
 

            MPI_Recv(&Columns_1, 1, MPI_INT, Starting_Point, 1, MPI_COMM_WORLD, &Current_Status);

 
            MPI_Recv(&No_of_columns2, 1, MPI_INT, Starting_Point, 1, MPI_COMM_WORLD, &Current_Status);

    
            MPI_Recv(&No_of_rows2, 1, MPI_INT, Starting_Point, 1, MPI_COMM_WORLD, &Current_Status);

            double matrixA[No_of_rows][Columns_1],matrixB[No_of_rows2][No_of_columns2],matrixC[No_of_rows][No_of_columns2];
    
            MPI_Recv(&matrixA, No_of_rows*Columns_1, MPI_DOUBLE, Starting_Point, 1, MPI_COMM_WORLD, &Current_Status);
 
            MPI_Recv(&matrixB, No_of_rows2*No_of_columns2, MPI_DOUBLE, Starting_Point, 1, MPI_COMM_WORLD, &Current_Status);
    

    int Counter_1 = 0;
    while ( Counter_1<No_of_columns2) 
          {
     
           int Counter_2 = 0;
      while ( Counter_2<No_of_rows) 
            {
      
        matrixC[Counter_2][Counter_1] = 0.0;
        
        int Counter_3 = 0;
        while ( Counter_3<No_of_rows2)
              {
              
          matrixC[Counter_2][Counter_1] = matrixC[Counter_2][Counter_1] + matrixA[Counter_2][Counter_3] * matrixB[Counter_3][Counter_1];
         
          Counter_3++;
        }
        
         Counter_2++;
      }
      
       Counter_1++;
    }
    

    MPI_Send(&offset, 1, MPI_INT, 0, 2, MPI_COMM_WORLD);
  
    MPI_Send(&No_of_rows, 1, MPI_INT, 0, 2, MPI_COMM_WORLD);

    MPI_Send(&matrixC, No_of_rows*No_of_columns2, MPI_DOUBLE, 0, 2, MPI_COMM_WORLD);
    ++Counter_0;
    
      }
  }

  MPI_Finalize();
}
