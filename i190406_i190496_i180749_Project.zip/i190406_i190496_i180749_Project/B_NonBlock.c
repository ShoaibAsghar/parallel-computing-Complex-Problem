#include <stdlib.h>
#include <stdio.h>
#include "mpi.h"
#include <time.h>
#include <sys/time.h>


void Multiplication_of_matrix(int Rows_1,int Columns_1,int Rows_2,int Columns_2, int No_of_Slave_Tasks,double Matrix_1[][Columns_1],double Matrix_2[][Columns_2],MPI_Request requ)
       {

	double Matrix_3[Rows_1][Columns_2];

	
	int No_of_Rows = Rows_1/No_of_Slave_Tasks;
	
	
	int offset = 0;
	int Ending_Point;
	int Starting_point;

	MPI_Status Current_Status;
	MPI_Request Current_request[No_of_Slave_Tasks];
	
	Ending_Point=1;
	
	while (Ending_Point <= No_of_Slave_Tasks) 
	      {
	      
		MPI_Request CurrentRequest[7];
      		
      		MPI_Isend(&offset, 1, MPI_INT, Ending_Point, 1, MPI_COMM_WORLD,&CurrentRequest[0]);
 		MPI_Wait(&CurrentRequest[0], &Current_Status);
      		
		MPI_Isend(&No_of_Rows, 1, MPI_INT, Ending_Point, 1, MPI_COMM_WORLD,&CurrentRequest[1]);
       	        MPI_Wait(&CurrentRequest[1], &Current_Status);
      		
      		MPI_Isend(&Columns_1, 1, MPI_INT, Ending_Point, 1, MPI_COMM_WORLD,&CurrentRequest[2]);
       	        MPI_Wait(&CurrentRequest[2], &Current_Status);
      		
      		MPI_Isend(&Columns_2, 1, MPI_INT, Ending_Point, 1, MPI_COMM_WORLD,&CurrentRequest[3]);
       	        MPI_Wait(&CurrentRequest[3], &Current_Status);
      		
      		MPI_Isend(&Rows_2, 1, MPI_INT, Ending_Point, 1, MPI_COMM_WORLD,&CurrentRequest[4]);
       	        MPI_Wait(&CurrentRequest[4], &Current_Status);
      		
      		MPI_Isend(&Matrix_1[offset][0], No_of_Rows*Columns_1, MPI_DOUBLE, Ending_Point, 1, MPI_COMM_WORLD,&CurrentRequest[5]);
       	        MPI_Wait(&CurrentRequest[5], &Current_Status);
      		
      		MPI_Isend(Matrix_2, Rows_2*Columns_2, MPI_DOUBLE, Ending_Point, 1, MPI_COMM_WORLD,&CurrentRequest[6]);
       	        MPI_Wait(&CurrentRequest[6], &Current_Status);
      
	       
	       offset = offset + No_of_Rows;
               Ending_Point++;
	}

    
}




MPI_Status Current_Status;

int main(int argc, char **argv) 
       {
       
  	int Number_of_Process, Current_Process_ID, No_of_Slave_Tasks , source, No_of_Rows, offset;
  	
  	struct timeval Start_Time, Stop_Time;

  	MPI_Init(&argc, &argv);

  	MPI_Comm_rank(MPI_COMM_WORLD, &Current_Process_ID);

  	MPI_Comm_size(MPI_COMM_WORLD, &Number_of_Process);

  	No_of_Slave_Tasks = Number_of_Process - 1;

  	if (Current_Process_ID == 0) 
  	   {
		MPI_Request CurrentRequest[8];
    		int Array_of_Rows[5] = {3, 7, 8, 4, 9};
    		int Array_of_Columns[5] = {7, 8, 4, 9, 10};

    		for (int Loop_Counter_1 = 0; Loop_Counter_1 < 5 - 1; ++Loop_Counter_1) {
      			int No_of_Rows_1 = Array_of_Rows[Loop_Counter_1];
      			int No_of_Columns_1 = Array_of_Columns[Loop_Counter_1];
      			int No_of_Rows_2 = Array_of_Rows[Loop_Counter_1 + 1];
      			int No_of_Columns_2 = Array_of_Columns[Loop_Counter_1 + 1];
      			double Matrix_1[No_of_Rows_1][No_of_Columns_1], Matrix_2[No_of_Rows_2][No_of_Columns_2], Matrix_3[No_of_Rows_1][No_of_Columns_2];

      			srand(time(NULL));


				int Loop_iterator_1 = 0;
				int Loop_iterator_2 = 0;
				int Loop_iterator_3 = 0;
				int Loop_iterator_4 = 0;
				int Loop_iterator_5 = 0;
				int Loop_iterator_6 = 0;
				int Loop_iterator_7 = 0;
				int Loop_iterator_8 = 0;
				int Loop_iterator_9 = 0;
				int Loop_iterator_10 = 0;


				int Loop_Counter_1 = 0; 
      			while (Loop_Counter_1 < No_of_Rows_1) 
      			      {
				int Loop_Counter_2 = 0;
				
        			while (Loop_Counter_2 < No_of_Columns_1) 
        			     {
        				Matrix_1[Loop_Counter_1][Loop_Counter_2] = Loop_Counter_1;
					Loop_Counter_2++;
        			     }
        			     
					Loop_Counter_1++;
      			     }

				
				int Loop_Counter_3 = 0;
				
      			while ( Loop_Counter_3 < No_of_Rows_2 )
      			      {
				int Loop_Counter_2 = 0;
				
        			while ( Loop_Counter_2 < No_of_Columns_2) 
        			       {
          				 Matrix_2[Loop_Counter_3][Loop_Counter_2] = Loop_Counter_3;
				         Loop_Counter_2++;
        			       }
        			       
					Loop_Counter_3++;
      			     }

      			printf("\n\t\tMatrix - Matrix Multiplication using MPI\n");
      			printf("\nMatrix A\n\n");
				
				int Loop_Counter_4 = 0;
      			while ( Loop_Counter_4 < No_of_Rows_1) 
      			      {
				int Loop_Counter_2 = 0; 
				
        			while (Loop_Counter_2 < No_of_Columns_1) 
        			      {
          			        printf("%.0f\t", Matrix_1[Loop_Counter_4][Loop_Counter_2]);
					Loop_Counter_2++;
        			     }
					Loop_Counter_4++;
        			        printf("\n");
      			     }
				

      			printf("\nMatrix B\n\n");
				int Loop_Counter_5 = 0;
				
      			while ( Loop_Counter_5 < No_of_Rows_2 ) 
      			      {
      			      
				int Loop_Counter_2 = 0;
				
        			while ( Loop_Counter_2 < No_of_Columns_2) 
        			      {
          				printf("%.0f\t", Matrix_2[Loop_Counter_5][Loop_Counter_2]);
				        Loop_Counter_2++;
        			      }
        			      
					Loop_Counter_5++;
        			        printf("\n");
      			   }

      			No_of_Rows = No_of_Rows_1 / No_of_Slave_Tasks;

      			offset = 0;
	
      			Multiplication_of_matrix(No_of_Rows_1, No_of_Columns_1, No_of_Rows_2, No_of_Columns_2, No_of_Slave_Tasks, Matrix_1, Matrix_2, CurrentRequest[Loop_Counter_1]);

      			MPI_Request Current_request[3];

				int Loop_Counter_6 = 1;
				
      			while ( Loop_Counter_6 <= No_of_Slave_Tasks) 
      			      {
        			source = Loop_Counter_6;

        			MPI_Irecv(&offset, 1, MPI_INT, source, 2, MPI_COMM_WORLD, &Current_request[0]);
        			MPI_Wait(&Current_request[0], &Current_Status);

        			MPI_Irecv(&No_of_Rows, 1, MPI_INT, source, 2, MPI_COMM_WORLD, &Current_request[1]);
        			MPI_Wait(&Current_request[1], &Current_Status);

        			MPI_Irecv(&Matrix_3[offset][0], No_of_Rows * No_of_Columns_2, MPI_DOUBLE, source, 2, MPI_COMM_WORLD, &Current_request[2]);
        			MPI_Wait(&Current_request[2], &Current_Status);
					 Loop_Counter_6++;
      			}

      			printf("\nResult Matrix C = Matrix A * Matrix B:\n\n");
				int Loop_Counter_7 = 0;
      			while ( Loop_Counter_7 < No_of_Rows_1) 
      			      {
				
				int Loop_Counter_2 = 0; 
				
        			while (Loop_Counter_2 < No_of_Columns_2)
        			      {
						printf("%.0f\t", Matrix_3[Loop_Counter_7][Loop_Counter_2]);
						Loop_Counter_2++;
					}
					
        			printf("\n");
			        Loop_Counter_7++;
      			}
      			
      			printf("\n");
    		}
  	}

  	if (Current_Process_ID > 0) 
  	   {
		int Loop_Counter_1 = 0;

    		while ( Loop_Counter_1 < 5 - 1) {
      			int No_of_Columns_1, No_of_Rows_2, No_of_Columns_2;

      			source = 0;
      			MPI_Request CurrentRequest[8];

      			MPI_Irecv(&offset, 1, MPI_INT, source, 1, MPI_COMM_WORLD, &CurrentRequest[0]);
      			MPI_Wait(&CurrentRequest[0], &Current_Status);
	
      			MPI_Irecv(&No_of_Rows, 1, MPI_INT, source, 1, MPI_COMM_WORLD, &CurrentRequest[1]);
      			MPI_Wait(&CurrentRequest[1], &Current_Status);
	
      			MPI_Irecv(&No_of_Columns_1, 1, MPI_INT, source, 1, MPI_COMM_WORLD, &CurrentRequest[2]);
      			MPI_Wait(&CurrentRequest[2], &Current_Status);

      			MPI_Irecv(&No_of_Columns_2, 1, MPI_INT, source, 1, MPI_COMM_WORLD, &CurrentRequest[3]);
      			MPI_Wait(&CurrentRequest[3], &Current_Status);

      			MPI_Irecv(&No_of_Rows_2, 1, MPI_INT, source, 1, MPI_COMM_WORLD, &CurrentRequest[4]);
      			MPI_Wait(&CurrentRequest[4], &Current_Status);

      			double matrixA[No_of_Rows][No_of_Columns_1], matrixB[No_of_Rows_2][No_of_Columns_2], matrixC[No_of_Rows][No_of_Columns_2];

      			MPI_Irecv(&matrixA, No_of_Rows * No_of_Columns_1, MPI_DOUBLE, source, 1, MPI_COMM_WORLD, &CurrentRequest[5]);
      			MPI_Wait(&CurrentRequest[5], &Current_Status);

      			MPI_Irecv(&matrixB, No_of_Rows_2 * No_of_Columns_2, MPI_DOUBLE, source, 1, MPI_COMM_WORLD, &CurrentRequest[6]);
      			MPI_Wait(&CurrentRequest[6], &Current_Status);
				
				int Loop_Counter_3 = 0;
				
      			while ( Loop_Counter_3 < No_of_Columns_2 ) 
      			      {
					int Loop_Counter_1 = 0;
        			while ( Loop_Counter_1 < No_of_Rows ) 
        			      {

          				matrixC[Loop_Counter_1][Loop_Counter_3] = 0.0;
						int Loop_Counter_2 = 0;
						
          				while ( Loop_Counter_2 < No_of_Rows_2) 
          				      {
            					matrixC[Loop_Counter_1][Loop_Counter_3] = matrixC[Loop_Counter_1][Loop_Counter_3] + matrixA[Loop_Counter_1][Loop_Counter_2] * matrixB[Loop_Counter_2][Loop_Counter_3];
          				 Loop_Counter_2++;
						 }
						 
						Loop_Counter_1++;
        			}
        			
					Loop_Counter_3++;
      			}

      			MPI_Request Current_request[3];
      			MPI_Status Current_Status;

      			MPI_Isend(&offset, 1, MPI_INT, 0, 2, MPI_COMM_WORLD, &Current_request[0]);
      			MPI_Wait(&Current_request[0], &Current_Status);

      			MPI_Isend(&No_of_Rows, 1, MPI_INT, 0, 2, MPI_COMM_WORLD, &Current_request[1]);
      			MPI_Wait(&Current_request[1], &Current_Status);

      			MPI_Isend(&matrixC, No_of_Rows * No_of_Columns_2, MPI_DOUBLE, 0, 2, MPI_COMM_WORLD, &Current_request[2]);
      			MPI_Wait(&Current_request[2], &Current_Status);
				++Loop_Counter_1;
    		}
	}

	MPI_Finalize();
}


